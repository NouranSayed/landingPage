## Landing Page Project
This project about build a multi-section landing page, with a dynamically updating navigational menu based on the amount of content that is added to the page.
 in this project the navbar menu items is added dynamically and doing the section in the view port is active.
## Project Files
1- js/app.js :contains the js code 
2-index.html :contains the landing page html code 
3-css/styles.css :containsthe css code

## used links
https://css-tricks.com/a-few-functional-uses-for-intersection-observer-to-know-when-an-element-is-in-view/
## personal information 
my name:nouran sayed ahmed .
